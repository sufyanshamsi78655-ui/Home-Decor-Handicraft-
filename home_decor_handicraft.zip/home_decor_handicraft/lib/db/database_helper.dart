import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/product.dart';

class DatabaseHelper {
  DatabaseHelper._internal();
  static final DatabaseHelper instance = DatabaseHelper._internal();

  static Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'home_decor_handicraft.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 0,
            costPrice REAL NOT NULL DEFAULT 0,
            imagePath TEXT
          )
        ''');
        await db.execute('CREATE INDEX idx_products_name ON products(name)');
      },
    );
  }

  Future<int> insertProduct(Product p) async {
    final db = await database;
    return db.insert('products', p.toMap()..remove('id'));
  }

  Future<int> updateProduct(Product p) async {
    final db = await database;
    return db.update('products', p.toMap(), where: 'id = ?', whereArgs: [p.id]);
  }

  Future<int> deleteProduct(int id) async {
    final db = await database;
    return db.delete('products', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Product>> getAllProducts() async {
    final db = await database;
    final rows = await db.query('products', orderBy: 'name COLLATE NOCASE ASC');
    return rows.map((r) => Product.fromMap(r)).toList();
  }

  /// Instant substring search across product name (case-insensitive, matches
  /// full name, partial name, or any word within it).
  Future<List<Product>> searchProducts(String query) async {
    final db = await database;
    final q = query.trim();
    if (q.isEmpty) return getAllProducts();
    final rows = await db.query(
      'products',
      where: 'name LIKE ?',
      whereArgs: ['%$q%'],
      orderBy: 'name COLLATE NOCASE ASC',
    );
    return rows.map((r) => Product.fromMap(r)).toList();
  }

  Future<int> getTotalProducts() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) as c FROM products');
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<int> getTotalQuantity() async {
    final db = await database;
    final result = await db.rawQuery('SELECT SUM(quantity) as s FROM products');
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<double> getTotalStockValue() async {
    final db = await database;
    final result = await db.rawQuery('SELECT SUM(quantity * costPrice) as s FROM products');
    final value = result.first['s'];
    if (value == null) return 0.0;
    return (value as num).toDouble();
  }

  /// Wipes all products (used during restore before re-inserting backup data).
  Future<void> clearAllProducts() async {
    final db = await database;
    await db.delete('products');
  }
}
