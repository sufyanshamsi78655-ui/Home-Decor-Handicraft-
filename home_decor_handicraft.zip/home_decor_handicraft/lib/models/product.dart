class Product {
  final int? id;
  final String name;
  final int quantity;
  final double costPrice;
  final String? imagePath; // local file path, nullable

  Product({
    this.id,
    required this.name,
    required this.quantity,
    required this.costPrice,
    this.imagePath,
  });

  double get stockValue => quantity * costPrice;

  Product copyWith({
    int? id,
    String? name,
    int? quantity,
    double? costPrice,
    String? imagePath,
    bool clearImage = false,
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      quantity: quantity ?? this.quantity,
      costPrice: costPrice ?? this.costPrice,
      imagePath: clearImage ? null : (imagePath ?? this.imagePath),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'quantity': quantity,
      'costPrice': costPrice,
      'imagePath': imagePath,
    };
  }

  factory Product.fromMap(Map<String, dynamic> map) {
    return Product(
      id: map['id'] as int?,
      name: map['name'] as String,
      quantity: map['quantity'] as int,
      costPrice: (map['costPrice'] as num).toDouble(),
      imagePath: map['imagePath'] as String?,
    );
  }

  // For JSON backup (image embedded separately as base64 by caller)
  Map<String, dynamic> toBackupMap(String? imageBase64) {
    return {
      'name': name,
      'quantity': quantity,
      'costPrice': costPrice,
      'imageBase64': imageBase64,
    };
  }
}
