import 'package:intl/intl.dart';

final NumberFormat _inrFormat = NumberFormat.currency(
  locale: 'en_IN',
  symbol: '₹',
  decimalDigits: 0,
);

final NumberFormat _plainIndianNumber = NumberFormat.decimalPattern('en_IN');

String formatRupees(num value) {
  return _inrFormat.format(value);
}

String formatNumber(num value) {
  return _plainIndianNumber.format(value);
}
