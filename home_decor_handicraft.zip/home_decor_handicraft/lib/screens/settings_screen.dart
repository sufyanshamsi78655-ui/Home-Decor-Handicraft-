import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../db/database_helper.dart';
import '../models/product.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _busy = false;
  String? _statusMessage;

  Future<void> _exportBackup() async {
    setState(() {
      _busy = true;
      _statusMessage = null;
    });
    try {
      final products = await DatabaseHelper.instance.getAllProducts();
      final List<Map<String, dynamic>> backupItems = [];

      for (final product in products) {
        String? imageBase64;
        if (product.imagePath != null) {
          final file = File(product.imagePath!);
          if (await file.exists()) {
            final bytes = await file.readAsBytes();
            imageBase64 = base64Encode(bytes);
          }
        }
        backupItems.add(product.toBackupMap(imageBase64));
      }

      final backup = {
        'app': 'Home Decor Handicraft',
        'version': 1,
        'exportedAt': DateTime.now().toIso8601String(),
        'products': backupItems,
      };

      final tempDir = await getTemporaryDirectory();
      final fileName =
          'home_decor_handicraft_backup_${DateTime.now().millisecondsSinceEpoch}.json';
      final file = File(p.join(tempDir.path, fileName));
      await file.writeAsString(jsonEncode(backup));

      await Share.shareXFiles([XFile(file.path)], text: 'Home Decor Handicraft stock backup');

      setState(() => _statusMessage = 'Backup created: $fileName');
    } catch (e) {
      setState(() => _statusMessage = 'Export failed: $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  Future<void> _importBackup() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Import backup?'),
        content: const Text(
            'This will replace ALL current products with the data from the backup file. This cannot be undone. Continue?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('CANCEL')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('IMPORT', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() {
      _busy = true;
      _statusMessage = null;
    });
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['json'],
      );
      if (result == null || result.files.single.path == null) {
        setState(() => _busy = false);
        return;
      }

      final file = File(result.files.single.path!);
      final content = await file.readAsString();
      final data = jsonDecode(content) as Map<String, dynamic>;
      final items = (data['products'] as List).cast<Map<String, dynamic>>();

      final appDir = await getApplicationDocumentsDirectory();
      final imagesDir = Directory(p.join(appDir.path, 'product_images'));
      if (!await imagesDir.exists()) {
        await imagesDir.create(recursive: true);
      }

      await DatabaseHelper.instance.clearAllProducts();

      for (final item in items) {
        String? imagePath;
        final imageBase64 = item['imageBase64'] as String?;
        if (imageBase64 != null && imageBase64.isNotEmpty) {
          final bytes = base64Decode(imageBase64);
          final fileName = 'restored_${DateTime.now().microsecondsSinceEpoch}.jpg';
          final savedFile = File(p.join(imagesDir.path, fileName));
          await savedFile.writeAsBytes(bytes);
          imagePath = savedFile.path;
        }

        final product = Product(
          name: item['name'] as String,
          quantity: (item['quantity'] as num).toInt(),
          costPrice: (item['costPrice'] as num).toDouble(),
          imagePath: imagePath,
        );
        await DatabaseHelper.instance.insertProduct(product);
      }

      setState(() => _statusMessage = 'Restored ${items.length} products successfully.');
    } catch (e) {
      setState(() => _statusMessage = 'Import failed: $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            child: ListTile(
              leading: const Icon(Icons.upload_file, size: 30),
              title: const Text('Export Backup', style: TextStyle(fontSize: 17)),
              subtitle: const Text('Save all products and images to a backup file'),
              onTap: _busy ? null : _exportBackup,
            ),
          ),
          const SizedBox(height: 12),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            child: ListTile(
              leading: const Icon(Icons.download, size: 30),
              title: const Text('Import Backup', style: TextStyle(fontSize: 17)),
              subtitle: const Text('Restore products from a backup file'),
              onTap: _busy ? null : _importBackup,
            ),
          ),
          if (_busy) const Padding(
            padding: EdgeInsets.only(top: 24),
            child: Center(child: CircularProgressIndicator()),
          ),
          if (_statusMessage != null)
            Padding(
              padding: const EdgeInsets.only(top: 24),
              child: Text(
                _statusMessage!,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 15, color: Colors.black87),
              ),
            ),
          const SizedBox(height: 32),
          const Center(
            child: Text('Home Decor Handicraft v1.0', style: TextStyle(color: Colors.black38)),
          ),
        ],
      ),
    );
  }
}
