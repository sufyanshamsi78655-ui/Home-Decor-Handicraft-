import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../db/database_helper.dart';
import '../models/product.dart';
import '../utils/formatters.dart';

class ProductFormScreen extends StatefulWidget {
  final Product? product; // null => add mode

  const ProductFormScreen({super.key, this.product});

  @override
  State<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _quantityController;
  late TextEditingController _costController;

  String? _imagePath;
  bool _saving = false;

  bool get _isEdit => widget.product != null;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.product?.name ?? '');
    _quantityController = TextEditingController(
        text: widget.product != null ? widget.product!.quantity.toString() : '');
    _costController = TextEditingController(
        text: widget.product != null ? _trimZero(widget.product!.costPrice) : '');
    _imagePath = widget.product?.imagePath;
  }

  String _trimZero(double v) {
    if (v == v.roundToDouble()) return v.toInt().toString();
    return v.toString();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _quantityController.dispose();
    _costController.dispose();
    super.dispose();
  }

  Future<void> _pickImage(ImageSource source) async {
    final picker = ImagePicker();
    final XFile? picked = await picker.pickImage(
      source: source,
      maxWidth: 1024,
      maxHeight: 1024,
      imageQuality: 70, // compress to save storage
    );
    if (picked == null) return;

    final appDir = await getApplicationDocumentsDirectory();
    final imagesDir = Directory(p.join(appDir.path, 'product_images'));
    if (!await imagesDir.exists()) {
      await imagesDir.create(recursive: true);
    }
    final fileName = 'img_${DateTime.now().millisecondsSinceEpoch}${p.extension(picked.path)}';
    final savedPath = p.join(imagesDir.path, fileName);
    await File(picked.path).copy(savedPath);

    setState(() => _imagePath = savedPath);
  }

  void _removeImage() {
    setState(() => _imagePath = null);
  }

  void _showImageOptions() {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera),
              title: const Text('Take Photo'),
              onTap: () {
                Navigator.pop(ctx);
                _pickImage(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Choose from Gallery'),
              onTap: () {
                Navigator.pop(ctx);
                _pickImage(ImageSource.gallery);
              },
            ),
            if (_imagePath != null)
              ListTile(
                leading: const Icon(Icons.delete, color: Colors.red),
                title: const Text('Remove Photo', style: TextStyle(color: Colors.red)),
                onTap: () {
                  Navigator.pop(ctx);
                  _removeImage();
                },
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);

    final name = _nameController.text.trim();
    final quantity = int.parse(_quantityController.text.trim());
    final cost = double.parse(_costController.text.trim());

    final product = Product(
      id: widget.product?.id,
      name: name,
      quantity: quantity,
      costPrice: cost,
      imagePath: _imagePath,
    );

    if (_isEdit) {
      await DatabaseHelper.instance.updateProduct(product);
    } else {
      await DatabaseHelper.instance.insertProduct(product);
    }

    if (!mounted) return;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? 'Edit Product' : 'Add Product')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Center(
              child: GestureDetector(
                onTap: _showImageOptions,
                child: Container(
                  width: 140,
                  height: 140,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: _imagePath != null && File(_imagePath!).existsSync()
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: Image.file(File(_imagePath!), fit: BoxFit.cover),
                        )
                      : const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.add_a_photo, size: 36, color: Colors.grey),
                            SizedBox(height: 8),
                            Text('Add Photo (optional)', style: TextStyle(color: Colors.grey)),
                          ],
                        ),
                ),
              ),
            ),
            const SizedBox(height: 28),
            TextFormField(
              controller: _nameController,
              style: const TextStyle(fontSize: 18),
              decoration: const InputDecoration(
                labelText: 'Product Name',
                border: OutlineInputBorder(),
              ),
              validator: (v) {
                if (v == null || v.trim().isEmpty) return 'Product name is required';
                return null;
              },
            ),
            const SizedBox(height: 18),
            TextFormField(
              controller: _quantityController,
              style: const TextStyle(fontSize: 18),
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Quantity',
                border: OutlineInputBorder(),
              ),
              validator: (v) {
                if (v == null || v.trim().isEmpty) return 'Quantity is required';
                final n = int.tryParse(v.trim());
                if (n == null) return 'Enter a valid whole number';
                if (n < 0) return 'Quantity cannot be negative';
                return null;
              },
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 18),
            TextFormField(
              controller: _costController,
              style: const TextStyle(fontSize: 18),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Cost Price (₹)',
                border: OutlineInputBorder(),
                prefixText: '₹ ',
              ),
              validator: (v) {
                if (v == null || v.trim().isEmpty) return 'Cost price is required';
                final n = double.tryParse(v.trim());
                if (n == null) return 'Enter a valid price';
                if (n < 0) return 'Cost price cannot be negative';
                return null;
              },
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 20),
            _buildStockValuePreview(),
            const SizedBox(height: 32),
            SizedBox(
              height: 54,
              child: ElevatedButton(
                onPressed: _saving ? null : _save,
                style: ElevatedButton.styleFrom(
                  textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                child: Text(_saving ? 'Saving...' : (_isEdit ? 'SAVE CHANGES' : 'SAVE PRODUCT')),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStockValuePreview() {
    final qty = int.tryParse(_quantityController.text.trim());
    final cost = double.tryParse(_costController.text.trim());
    final value = (qty != null && cost != null && qty >= 0 && cost >= 0) ? qty * cost : null;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.green.shade50,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Stock Value', style: TextStyle(fontSize: 16)),
          Text(
            value != null ? formatRupees(value) : '—',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.green),
          ),
        ],
      ),
    );
  }
}
