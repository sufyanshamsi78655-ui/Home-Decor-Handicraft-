import 'package:flutter/material.dart';
import '../db/database_helper.dart';
import '../models/product.dart';
import '../utils/formatters.dart';
import '../widgets/product_card.dart';
import 'product_form_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<Product> _results = [];
  bool _searched = false;

  int _totalProducts = 0;
  int _totalQuantity = 0;
  double _totalStockValue = 0;

  @override
  void initState() {
    super.initState();
    _loadTotals();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadTotals() async {
    final db = DatabaseHelper.instance;
    final products = await db.getTotalProducts();
    final quantity = await db.getTotalQuantity();
    final value = await db.getTotalStockValue();
    if (!mounted) return;
    setState(() {
      _totalProducts = products;
      _totalQuantity = quantity;
      _totalStockValue = value;
    });
  }

  Future<void> _onSearchChanged() async {
    final query = _searchController.text;
    if (query.trim().isEmpty) {
      setState(() {
        _results = [];
        _searched = false;
      });
      return;
    }
    final results = await DatabaseHelper.instance.searchProducts(query);
    if (!mounted) return;
    setState(() {
      _results = results;
      _searched = true;
    });
  }

  Future<void> _refreshAfterReturn() async {
    await _loadTotals();
    if (_searched) await _onSearchChanged();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home Decor Handicraft')),
      body: RefreshIndicator(
        onRefresh: _refreshAfterReturn,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'SEARCH PRODUCT AVAILABILITY',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 0.5, color: Colors.black54),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _searchController,
              style: const TextStyle(fontSize: 18),
              decoration: InputDecoration(
                hintText: 'Search by product name...',
                prefixIcon: const Icon(Icons.search, size: 28),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () => _searchController.clear(),
                      )
                    : null,
                filled: true,
                fillColor: Colors.grey.shade100,
                contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 20),
            if (!_searched) _buildTotalsCard(),
            if (_searched) _buildSearchResults(),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: const Text('ADD PRODUCT'),
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const ProductFormScreen()),
          );
          _refreshAfterReturn();
        },
      ),
    );
  }

  Widget _buildTotalsCard() {
    return Card(
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            _statRow('Total Products', formatNumber(_totalProducts)),
            const Divider(height: 28),
            _statRow('Total Quantity', formatNumber(_totalQuantity)),
            const Divider(height: 28),
            _statRow('Total Stock Value', formatRupees(_totalStockValue), emphasize: true),
          ],
        ),
      ),
    );
  }

  Widget _statRow(String label, String value, {bool emphasize = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(fontSize: 16, color: Colors.black87)),
        Text(
          value,
          style: TextStyle(
            fontSize: emphasize ? 22 : 20,
            fontWeight: FontWeight.bold,
            color: emphasize ? Colors.green.shade800 : Colors.black,
          ),
        ),
      ],
    );
  }

  Widget _buildSearchResults() {
    if (_results.isEmpty) {
      return const Padding(
        padding: EdgeInsets.only(top: 40),
        child: Center(
          child: Text('Product not found', style: TextStyle(fontSize: 18, color: Colors.black54)),
        ),
      );
    }
    return Column(
      children: _results
          .map((p) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: ProductCard(
                  product: p,
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => ProductFormScreen(product: p)),
                    );
                    _refreshAfterReturn();
                  },
                ),
              ))
          .toList(),
    );
  }
}
